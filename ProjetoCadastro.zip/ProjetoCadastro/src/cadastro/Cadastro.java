


package cadastro;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
 
public class Cadastro {
    
     public static void main(String[] args) {
        // TODO code application logic here
      
      //Parâmetros para a conexão com BD  
      String DB_URL = "jdbc:mysql://localhost/Cadastro";
      String USER = "root";
      String PASS = "";
    
      
     /* Insert, Update e Delete é por executeUpdate()*/
    String QUERY = "insert into pessoas(id, nome, cpf, cidade, uf) values (?,?,?,?,?,?)";
    String QUERYUPDATE = "update pessoas set nome = ? where id = ?";
    String QUERYDELETE = "delete from pessoas where id = ?";
    
    
    String QUERYSELECT = "select * from pessoas order by nome";
    
    
    try{ 
     
         
         /*Tentativa de estabelecer a conexão com o BD   
           Caso dê certo a variável "conn" terá uma instância de conexão com o BD*/         
         Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
         
         //Prepara a instrução SQL a ser executada 
         PreparedStatement pst = conn.prepareStatement(QUERYSELECT);
         
         //Alimentar as interrogações(parâmetros) conforme os tipos
         //pst.setInt(1, 1);
         
         //Executar a instrução preparada
         ResultSet rst = pst.executeQuery();
         
          //Varredura da estrutura do ResultSet com acesso as colunas
         while(rst.next()){
             System.out.println("ID: "+rst.getInt("id"));
             System.out.println("NOME: "+rst.getString("nome"));
             System.out.println("CPF: "+rst.getInt("cpf"));   
             System.out.println("CIDADE:" + rst.getString("cidade"));
             System.out.println("UF: "+rst.getString("uf"));
             System.out.println("--------------------------");
         }
     
          

      } catch (SQLException e) {
      } 
     
            
    }
    
}

     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
