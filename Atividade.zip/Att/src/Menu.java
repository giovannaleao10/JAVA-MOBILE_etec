
import javax.swing.JOptionPane;

public class Menu {

    public static void main(String[] args) {

        
       

        
        String nome = null;
        String sobrenome = null;
        String cpfcnpj = null;
        String tipodepessoa = null;
        String cidade = null;
        String uf = null;
        double limitedecredito = 0;
        boolean direitoaprazo = true;

        
        
        cliente c = new cliente(nome, sobrenome, cpfcnpj, tipodepessoa, cidade, uf, limitedecredito, direitoaprazo);

        int prazodeEntregaDias = 0;
        
        fornecedor f = new fornecedor (nome, sobrenome, cpfcnpj, tipodepessoa, cidade, uf, prazodeEntregaDias);

     
   boolean continuar = true;

        while (continuar) {
        int opcao = 0;
        while (opcao != 7) {
           
            String menu = "Escolha uma opção:\n";
            menu += "1 - Cadastrar cliente\n";
            menu += "2 - Cadastrar fornecedor\n";
            menu += "3 - Alterar Cliente\n";
            menu += "4 - Alterar Fornecedor\n";
            menu += "5 - Imprimir Cliente\n";
            menu += "6 - Imprimir Fornecedor\n";
            menu += "7 - Sair\n";
            String strOpcao = JOptionPane.showInputDialog(null, menu);

            try {
                opcao = Integer.parseInt(strOpcao);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Opção inválida! Digite um número de 1 a 7.");
                continue;
            }

            switch (opcao) {
                case 1:
                     nome = JOptionPane.showInputDialog(null, "Digite o nome do cliente:");
                     sobrenome = JOptionPane.showInputDialog(null, "Digite o sobrenome do cliente:");
                     cpfcnpj = JOptionPane.showInputDialog(null, "Digite o CPF/CNPJ do cliente:");
                     tipodepessoa = JOptionPane.showInputDialog(null, "Digite o tipo de pessoa (F ou J):");
                     cidade = JOptionPane.showInputDialog(null, "Digite a cidade do cliente:");
                     uf = JOptionPane.showInputDialog(null, "Digite o estado do cliente:");
                     limitedecredito = Double.parseDouble (JOptionPane.showInputDialog(null, "Digite o limite de crédito do cliente:"));
                    String strDireitoAPrazo = JOptionPane.showInputDialog(null, "O cliente tem direito a prazo (S ou N)?");
                    direitoaprazo = strDireitoAPrazo.equalsIgnoreCase("S/N");
                    
                    c.setNome(nome);
                    c.setSobrenome(sobrenome);
                    c.setCpfcnpj(cpfcnpj);
                    c.setTipodepessoa(tipodepessoa);
                    c.setCidade(cidade);
                    c.setUf(uf);
                    c.setLimitedecredito(limitedecredito);
                    c.setDireitoaprazo(direitoaprazo);
        
                    JOptionPane.showMessageDialog(null, "Cliente cadastrado com sucesso!");
                    break;
                default:
                    
                case 2:
                    nome = JOptionPane.showInputDialog(null, "Digite o nome do fornecedor:");
                     sobrenome = JOptionPane.showInputDialog(null, "Digite o sobrenome do fornecedor:");
                     cpfcnpj = JOptionPane.showInputDialog(null, "Digite o CPF/CNPJ do fornecedor:");
                     tipodepessoa = JOptionPane.showInputDialog(null, "Digite o tipo de pessoa (F ou J):");
                     cidade = JOptionPane.showInputDialog(null, "Digite a cidade do fornecedor:");
                     uf = JOptionPane.showInputDialog(null, "Digite o UF do fornecedor:");
                     prazodeEntregaDias = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o Prazo de entrega de dias do fornecedor:"));
                    f.setNome(nome);
                    f.setSobrenome(sobrenome);
                    f.setCpfcnpj(cpfcnpj);
                    f.setTipodepessoa(tipodepessoa);
                    f.setCidade(cidade);
                    f.setUf(uf);
                    f.setPrazodeEntregaDias(prazodeEntregaDias);
        
                    JOptionPane.showMessageDialog(null, "Fornecedor cadastrado com sucesso!");
                     break;
            
                
                case 3:
             
                nome = JOptionPane.showInputDialog("Digite o novo nome do cliente:");
                sobrenome = JOptionPane.showInputDialog("Digite o novo sobrenome do cliente:");
                tipodepessoa = JOptionPane.showInputDialog("Digite o novo tipo de pessoa do cliente (F/J):");
                cidade = JOptionPane.showInputDialog("Digite a nova cidade do cliente:");
                uf = JOptionPane.showInputDialog("Digite o novo UF do cliente:");
                limitedecredito = Double.parseDouble(JOptionPane.showInputDialog("Digite o novo limite de crédito do cliente:"));
                direitoaprazo = Boolean.parseBoolean(JOptionPane.showInputDialog("O cliente tem direito a prazo (S/N)?"));
                
                    c.setNome(nome);
                    c.setSobrenome(sobrenome);
                    c.setCpfcnpj(cpfcnpj);
                    c.setTipodepessoa(tipodepessoa);
                    c.setCidade(cidade);
                    c.setUf(uf);
                    c.setLimitedecredito(limitedecredito);
                    c.setDireitoaprazo(direitoaprazo);
                    JOptionPane.showMessageDialog(null, "Cliente alterado com sucesso!");

break;            
                case 4:
                nome = JOptionPane.showInputDialog("Digite o novo nome do fornecedor:");
                sobrenome = JOptionPane.showInputDialog("Digite o novo sobrenome do fornecedor:");
                tipodepessoa = JOptionPane.showInputDialog("Digite o novo tipo de pessoa do fornecedor (F/J):");
                cidade = JOptionPane.showInputDialog("Digite a nova cidade do fornecedor:");
                uf = JOptionPane.showInputDialog("Digite o novo UF do fornecedor:");
                prazodeEntregaDias = Integer.parseInt(JOptionPane.showInputDialog("Digite o novo prazo de entrega de dias: "));
                
                    f.setNome(nome);
                    f.setSobrenome(sobrenome);
                    f.setCpfcnpj(cpfcnpj);
                    f.setTipodepessoa(tipodepessoa);
                    f.setCidade(cidade);
                    f.setUf(uf);
                    f.setPrazodeEntregaDias(prazodeEntregaDias);
                    JOptionPane.showMessageDialog(null, "Cliente alterado com sucesso!");
                break;
                
                case 5:
                  JOptionPane.showMessageDialog(null,"Nome:" + c.getNome());
                  JOptionPane.showMessageDialog(null,"Sobrenome:" + c.getSobrenome());
                  JOptionPane.showMessageDialog(null,"Cpfcnpj: " + c.getCpfcnpj());
                  JOptionPane.showMessageDialog(null,"tipodepessoa: " + c.getTipodepessoa());
                  JOptionPane.showMessageDialog(null,"Cidade: " + c.getCidade());
                  JOptionPane.showMessageDialog(null,"UF: " + c.getUf());
                  JOptionPane.showMessageDialog(null,"Limite de Credito: " + c.getLimitedecredito());
                  JOptionPane.showMessageDialog(null,"Direito a prazo: " + c.getDireitoaprazo());
                break;
                
                case 6:
                  JOptionPane.showMessageDialog(null,"Nome:" + f.getNome());
                  JOptionPane.showMessageDialog(null,"Sobrenome:" + f.getSobrenome());
                  JOptionPane.showMessageDialog(null,"Cpfcnpj: " + f.getCpfcnpj());
                  JOptionPane.showMessageDialog(null,"tipodepessoa: " + f.getTipodepessoa());
                  JOptionPane.showMessageDialog(null,"Cidade: " + f.getCidade());
                  JOptionPane.showMessageDialog(null,"UF: " + f.getUf());
                  JOptionPane.showMessageDialog(null,"Prazo de Entrega em Dias: " + f.getPrazodeEntregaDias());

                 break;
                case 7:
                    System.exit(0);
                break;
                    


                

            }
        }
        
        }
    }
}

        


























        
        
        
        
        
                            
        
    

