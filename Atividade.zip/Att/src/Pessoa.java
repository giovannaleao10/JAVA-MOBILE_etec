/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author Aluno
 */


    
    public abstract class Pessoa {
    private String nome;
    private String sobrenome;
    private String cpfcnpj;
    private String tipodepessoa;
    private String cidade;
    private String uf;

    public Pessoa(String nome, String sobrenome, String cpfcnpj, String tipodepessoa, String cidade, String uf) {
        this.nome = nome;
        this.sobrenome = sobrenome;
        this.cpfcnpj = cpfcnpj;
        this.tipodepessoa = tipodepessoa;
        this.cidade = cidade;
        this.uf = uf;
    }

    // Métodos getters e setters
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSobrenome() {
        return sobrenome;
    }

    public void setSobrenome(String sobrenome) {
        this.sobrenome = sobrenome;
    }

    public String getCpfcnpj() {
        return cpfcnpj;
    }

    public void setCpfcnpj(String cpfcnpj) {
        this.cpfcnpj = cpfcnpj;
    }

    public String getTipodepessoa() {
        return tipodepessoa;
    }

    public void setTipodepessoa(String tipodepessoa) {
        this.tipodepessoa = tipodepessoa;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getUf() {
        return uf;
    }

    public void setUf(String uf) {
        this.uf = uf;
    }
}



