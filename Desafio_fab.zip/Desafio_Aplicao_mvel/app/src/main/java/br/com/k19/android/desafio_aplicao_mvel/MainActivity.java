package br.com.k19.android.desafio_aplicao_mvel;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setContentView(R.layout.activity_main);

        EditText qtdPessoa = (EditText)  findViewById(R.id.qtdPessoas);
        EditText qtdCasal = (EditText)  findViewById(R.id.qtdCasal);
        EditText vlrComanda = (EditText)  findViewById(R.id.vlrComanda);
        EditText vlrTaxaServico = (EditText)  findViewById(R.id.vlrTaxaServico);
        Button btnTotalServicoPessoa = (Button)  findViewById(R.id.btnTotalServPessoa);
        Button btnTotalServicoCasal = (Button)  findViewById(R.id.btnTotalServCasal);
        Button btnTotalServicoCasalPessoa = (Button)  findViewById(R.id.btnTotalServPessoaCasal);
        TextView txtTotalGeralBrutoSServico = (TextView) findViewById(R.id.txtGeralBrutoSServ);
        TextView txtTotalServico = (TextView) findViewById(R.id.txtTotalServico);
        TextView txtTotalGeralCServico = (TextView) findViewById(R.id.txtTotalGeralCServ);


        btnTotalServicoPessoa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Double totalGeralBrutoSServico = Double.parseDouble(vlrComanda.getText().toString()) / Double.parseDouble(qtdPessoa.getText().toString());
                txtTotalGeralBrutoSServico.setText("Total Geral Bruto S/Servico: " + totalGeralBrutoSServico.toString());

                txtTotalServico.setText("Total Serviço: " + vlrTaxaServico.getText().toString());

                Double totalGeralCServico = totalGeralBrutoSServico + Double.parseDouble(vlrTaxaServico.getText().toString());
                txtTotalGeralCServico.setText("Total Geral C/Servico: " + totalGeralCServico.toString());
            }
        });

        btnTotalServicoCasal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Double totalGeralBrutoSServico = (Double.parseDouble(vlrComanda.getText().toString()) / Double.parseDouble(qtdPessoa.getText().toString()) * (Double.parseDouble(qtdCasal.getText().toString()) * 2));
                txtTotalGeralBrutoSServico.setText("Total Geral Bruto S/Servico: " + totalGeralBrutoSServico.toString());

                Double totalServico = (Double.parseDouble(vlrComanda.getText().toString()) * Double.parseDouble(qtdCasal.getText().toString())) / 100;
                txtTotalServico.setText("Total Serviço: " + totalServico.toString());

                Double totalGeralCServico = totalGeralBrutoSServico + totalServico;
                txtTotalGeralCServico.setText("Total Geral C/Servico: " + totalGeralCServico.toString());
            }
        });

        btnTotalServicoCasalPessoa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Double valorPessoaPagar = Double.parseDouble(vlrComanda.getText().toString()) / Double.parseDouble(qtdPessoa.getText().toString());
                Double valorCasalPagar = (Double.parseDouble(vlrComanda.getText().toString()) / Double.parseDouble(qtdPessoa.getText().toString()) * (Double.parseDouble(qtdCasal.getText().toString()) * 2));
                txtTotalGeralBrutoSServico.setText("Total Pessoa Pagar: " + valorPessoaPagar.toString() + " Total Casal Pagar: " + valorCasalPagar);


                Double totalServicoPessoaPagar = Double.parseDouble(vlrTaxaServico.getText().toString());
                Double totalServicoCasalPagar = Double.parseDouble(vlrTaxaServico.getText().toString()) * (Double.parseDouble(qtdCasal.getText().toString()) * 2);
                txtTotalServico.setText("Total Serviço Pessoa Pagar: " + totalServicoPessoaPagar.toString() + " Total Servico Casal Pagar: " + totalServicoCasalPagar.toString());



                Double totalGeralCServPessoaPagar = valorPessoaPagar + totalServicoPessoaPagar;
                Double totalGeralCServCasalPagar = valorCasalPagar + totalServicoCasalPagar;
                txtTotalGeralCServico.setText("Total Geral C/Servico Pessoa Pagar: " + totalGeralCServPessoaPagar.toString() + " Total Geral C/ Servico Casal Pagar: " + totalGeralCServCasalPagar);
            }
        });



    }
}