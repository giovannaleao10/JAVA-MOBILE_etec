/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atividade;

/**
 *
 * @author Aluno
 */
public class fornecedor extends Pessoa {
    private int prazodeEntregaDias;

    public fornecedor(String nome, String sobrenome, String cpfcnpj, char tipodepessoa, String cidade, String uf,
            int prazodeEntregaDias) {
        super(nome, sobrenome, cpfcnpj, tipodepessoa, cidade, uf);
        this.prazodeEntregaDias = prazodeEntregaDias;
    }

    // Método getter e setter
    public int getPrazodeEntregaDias() {
        return prazodeEntregaDias;
    }

    public void setPrazodeEntregaDias(int prazodeEntregaDias) {
        this.prazodeEntregaDias = prazodeEntregaDias;
    }
}
