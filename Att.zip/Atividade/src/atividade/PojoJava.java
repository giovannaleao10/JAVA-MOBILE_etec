/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atividade;

/**
 *
 * @author Aluno
 */


  public class PojoJava {
    public static void main(String[] args) {
        // Instanciando um objeto Cliente
        cliente cliente = new cliente("José", "Silva", "789456123", 'F', "São Paulo", "SP", 1000.0, true);

        // Acessando os atributos do Cliente
        System.out.println("Nome do Cliente: " + cliente.getNome());
        System.out.println("Sobrenome do Cliente: " + cliente.getSobrenome());
        System.out.println("CPF/CNPJ do Cliente: " + cliente.getCpfcnpj());
        System.out.println("Tipo de Pessoa do Cliente: " + cliente.getTipodepessoa());
        System.out.println("Cidade do Cliente: " + cliente.getCidade());
        System.out.println("UF do Cliente: " + cliente.getUf());
        System.out.println("Limite de Crédito do Cliente: " + cliente.getLimitedecredito());
        System.out.println("Direito a Prazo do Cliente: " + cliente.isDireitoaprazo());

        System.out.println(); // Pula uma linha para separar a saída

        // Instanciando um objeto Fornecedor
        fornecedor fornecedor = new fornecedor("Shein", "China", "1597863585", 'J', "Curitiba", "PR", 7);

        // Acessando os atributos do Fornecedor
        System.out.println("Nome do Fornecedor: " + fornecedor.getNome());
        System.out.println("Sobrenome do Fornecedor: " + fornecedor.getSobrenome());
        System.out.println("CPF/CNPJ do Fornecedor: " + fornecedor.getCpfcnpj());
        System.out.println("Tipo de Pessoa do Fornecedor: " + fornecedor.getTipodepessoa());
        System.out.println("Cidade do Fornecedor: " + fornecedor.getCidade());
        System.out.println("UF do Fornecedor: " + fornecedor.getUf());
        System.out.println("Prazo de Entrega em Dias do Fornecedor: " + fornecedor.getPrazodeEntregaDias());
    }
}

 
