/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atividade;

/**
 *
 * @author Aluno
 */

    
    public class cliente extends Pessoa {
    private double limitedecredito;
    private boolean direitoaprazo;

    public cliente(String nome, String sobrenome, String cpfcnpj, char tipodepessoa, String cidade, String uf,
            double limitedecredito, boolean direitoaprazo) {
        super(nome, sobrenome, cpfcnpj, tipodepessoa, cidade, uf);
        this.limitedecredito = limitedecredito;
        this.direitoaprazo = direitoaprazo;
    }

    // Métodos getters e setters
    public double getLimitedecredito() {
        return limitedecredito;
    }

    public void setLimitedecredito(double limitedecredito) {
        this.limitedecredito = limitedecredito;
    }

    public boolean isDireitoaprazo() {
        return direitoaprazo;
    }

    public void setDireitoaprazo(boolean direitoaprazo) {
        this.direitoaprazo = direitoaprazo;
    }
}

    

